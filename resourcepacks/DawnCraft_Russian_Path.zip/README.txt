Cоздал этот RP: ItDanieru

Перевели: ItDanieru и ArmaGEEDoH.